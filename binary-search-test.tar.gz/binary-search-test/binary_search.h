#ifndef BINARY_SEARCH_H__
#define BINARY_SEARCH_H__

int binary_search(int sorted_array[], int first, int last, int key);

#endif
