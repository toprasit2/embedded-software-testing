
#include <stdio.h>
#include <memory.h>
#include <setjmp.h>
#include <cmocka.h>

static void test_sprintf_with_no_format_operation(void **state)
{
    (void) state;
    char output[5] = "";
    
    assert_int_equal(sprintf(output, "hey"), 3);
    assert_string_equal("hey", output);
}


int main(int ac, char** av)
{
   const struct CMUnitTest tests[] = {
       cmocka_unit_test(test_sprintf_with_no_format_operation),
   };
   return cmocka_run_group_tests(tests, NULL, NULL);
}
