#ifndef __FIZZ_BUZZ__H
#define __FIZZ_BUZZ__H

void fizz_buzz(int number, char* output);

#endif
